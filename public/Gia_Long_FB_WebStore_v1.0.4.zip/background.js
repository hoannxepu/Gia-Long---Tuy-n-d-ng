// background.js - Điều phối Đăng Bài Facebook & Hẹn Giờ Chuẩn 100% Manifest V3
// Hỗ trợ: Dừng tức thì, Hẹn giờ chuẩn Alarms, Lịch sử đăng bài, Dò tìm & Tham gia nhóm, Giữ kết nối Web App

try {
  importScripts('storage.js');
  importScripts('spintax.js');
  importScripts('ed25519_verify.js');
  importScripts('accounts_manager.js');
  importScripts('fb_runner.js');
  importScripts('alarms_manager.js');
} catch (e) {
  console.warn('[Background] importScripts notice:', e);
}

let isRunning = false;
let shouldStop = false;
let activeTabId = null;

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// Chống ngủ Service Worker trong Manifest V3 thông qua Alarms chu kỳ 30s
function startKeepAlive() {
  if (typeof AlarmsManager !== 'undefined') {
    AlarmsManager.startKeepAlive();
  }
}

function stopKeepAlive() {
  if (typeof AlarmsManager !== 'undefined') {
    AlarmsManager.stopKeepAlive();
  }
}

// Cập nhật trạng thái tiến trình vào storage
async function updateStatus(status) {
  try {
    await chrome.storage.local.set({ postJobState: status });
  } catch (e) {}
}

// GHI LỊCH SỬ ĐĂNG BÀI (Đồng bộ qua FbRunner.appendHistoryEntry & SharedStorage mutex, giữ tối đa 1.000 bản ghi)
async function addHistoryEntry(entry) {
  try {
    if (typeof FbRunner !== 'undefined' && typeof FbRunner.appendHistoryEntry === 'function') {
      await FbRunner.appendHistoryEntry(entry);
      return;
    }
    const res = await chrome.storage.local.get(['postHistory', 'fbAccounts', 'activeAccountId']);
    const history = Array.isArray(res.postHistory) ? res.postHistory : [];
    const accounts = Array.isArray(res.fbAccounts) ? res.fbAccounts : [];
    const activeAcc = accounts.find((a) => a.id === res.activeAccountId) || accounts[0] || null;
    const newEntry = {
      id: 'hist_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      timestamp: Date.now(),
      timeFormatted: new Date().toLocaleString('vi-VN'),
      accountId: entry.accountId || (activeAcc ? activeAcc.id : 'default'),
      accountName: entry.accountName || (activeAcc ? activeAcc.name : 'Tài khoản mặc định'),
      cUser: entry.cUser || (activeAcc ? activeAcc.cUser || '' : ''),
      ...entry,
    };
    const updated = [newEntry, ...history].slice(0, 1000);
    await chrome.storage.local.set({ postHistory: updated });
    console.log('[AutoRecruit Background] Đã ghi lịch sử:', newEntry.status, newEntry.groupName);
  } catch (err) {
    console.warn('[AutoRecruit Background] Lỗi ghi lịch sử:', err);
  }
}

// ==========================================
// HỆ THỐNG QUẢN LÝ BẢN QUYỀN (LICENSE MANAGER)
// Hỗ trợ cả Cá Nhân (1 máy) & Doanh Nghiệp (Team N máy)
// ==========================================
const PRODUCTION_API_BASE = 'https://gia-long---tuy-n-d-ng.pages.dev';

async function getOrCreateDeviceId() {
  try {
    const data = await chrome.storage.local.get(['autorecruit_device_id']);
    if (data.autorecruit_device_id && data.autorecruit_device_id !== 'Đang lấy...' && !data.autorecruit_device_id.includes('đang lấy') && String(data.autorecruit_device_id).trim() !== '') {
      return data.autorecruit_device_id;
    }

    try {
      if (chrome.storage && chrome.storage.sync) {
        const syncData = await chrome.storage.sync.get(['autorecruit_device_id']);
        if (syncData.autorecruit_device_id && syncData.autorecruit_device_id !== 'Đang lấy...' && !syncData.autorecruit_device_id.includes('đang lấy') && String(syncData.autorecruit_device_id).trim() !== '') {
          await chrome.storage.local.set({ autorecruit_device_id: syncData.autorecruit_device_id });
          return syncData.autorecruit_device_id;
        }
      }
    } catch (e) {}

    const newId = (typeof crypto !== 'undefined' && crypto.randomUUID) ? crypto.randomUUID() : ('dev_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 9));
    await chrome.storage.local.set({ autorecruit_device_id: newId });
    try {
      if (chrome.storage && chrome.storage.sync) {
        await chrome.storage.sync.set({ autorecruit_device_id: newId });
      }
    } catch (e) {}
    return newId;
  } catch (e) {
    return (typeof crypto !== 'undefined' && crypto.randomUUID) ? crypto.randomUUID() : 'dev_pc_' + Date.now().toString(36);
  }
}

async function getApiBaseUrl() {
  try {
    const data = await chrome.storage.local.get(['customApiServerUrl']);
    if (data.customApiServerUrl && String(data.customApiServerUrl).trim().startsWith('http')) {
      return data.customApiServerUrl.trim().replace(/\/+$/, '');
    }
  } catch (e) {}
  return PRODUCTION_API_BASE;
}

function getCandidateServerUrls(primaryBase = null) {
  if (primaryBase && primaryBase.startsWith('http')) {
    return [primaryBase.trim().replace(/\/+$/, '')];
  }
  return [PRODUCTION_API_BASE];
}

async function getAllServerCandidates(primaryBase = null) {
  return getCandidateServerUrls(primaryBase);
}

// ========================================================
// HỆ THỐNG KIỂM TRA NHANH & LƯU CACHE THÔNG MINH CHO EXTENSION
// Cơ chế: Khi mua gói -> kiểm tra 3s/lần trong 3-5 phút
// Khi dùng hàng ngày -> đọc từ bộ nhớ máy (chrome.storage),
// ngầm kiểm tra lại 60 phút/lần -> 100% MIỄN PHÍ KỂ CẢ HÀNG NGHÌN MÁY!
// ========================================================
let fastPollInterval = null;
let fastPollSecondsElapsed = 0;

function startFastLicensePolling(machineId, maxSeconds = 300) {
  if (fastPollInterval) {
    clearInterval(fastPollInterval);
    fastPollInterval = null;
  }
  fastPollSecondsElapsed = 0;
  console.log(`[Fast Polling D1] 🚀 Bắt đầu chế độ kiểm tra siêu tốc (2 giây/lần) cho máy: ${machineId}...`);

  fastPollInterval = setInterval(async () => {
    fastPollSecondsElapsed += 2;
    if (fastPollSecondsElapsed >= maxSeconds) {
      console.log('[Fast Polling D1] Đã kết thúc chu kỳ kiểm tra nhanh (5 phút). Chuyển sang chế độ chạy nền.');
      clearInterval(fastPollInterval);
      fastPollInterval = null;
      return;
    }

    try {
      const primaryBase = await getApiBaseUrl();
      const serverCandidates = getCandidateServerUrls(primaryBase);
      for (const base of serverCandidates) {
        try {
          const resp = await fetch(`${base}/api/check?machine_id=${encodeURIComponent(machineId)}`, {
            cache: 'no-store',
          });
          if (!resp.ok) continue;
          const data = await resp.json();
          if (data && data.success && data.status === 'active') {
            console.log('[Fast Polling D1] 🎉 QUẢN TRỊ VIÊN ĐÃ PHÊ DUYỆT BẢN QUYỀN VIP!', data);
            clearInterval(fastPollInterval);
            fastPollInterval = null;

            const cacheData = {
              signedToken: data.token,
              licenseStatus: 'active',
              expiresAt: data.expires_at,
              lastCheckedAt: Date.now(),
              cachedPkgName: data.pkg_name,
              isVip: true,
              licenseKey: data.token || data.license_key || 'GLFB-VIP-ACTIVE',
              isRevoked: false,
              licenseData: {
                key: data.token || data.license_key || 'GLFB-VIP-ACTIVE',
                expiresAt: data.expires_at,
                clientName: data.client_name || 'Khách Đặt Mua',
                notes: data.pkg_name || 'Bản quyền VIP Gia Long',
                daysLeft: data.days_left || 30,
                lastVerifiedAt: Date.now(),
              },
            };

            await chrome.storage.local.set(cacheData);

            // Bắn tin báo tới tất cả tabs & dashboard để cập nhật giao diện ngay
            try {
              if (chrome.tabs && chrome.tabs.query) {
                chrome.tabs.query({}).then((tabs) => {
                  tabs.forEach((tab) => {
                    if (tab.id) {
                      chrome.tabs.sendMessage(tab.id, {
                        action: 'VIP_ACTIVATED_FAST',
                        data: cacheData,
                      }).catch(() => {});
                    }
                  });
                }).catch(() => {});
              }
            } catch (e) {}

            return;
          }
        } catch (err) {}
      }
    } catch (e) {}
  }, 2000);
}

// Kiểm tra ngầm và đồng bộ tức thì với máy chủ sau mỗi 10-15 giây mà không làm gián đoạn người dùng
let isCheckingBackground = false;
async function checkServerBackground(machineId, token) {
  if (isCheckingBackground) return null;
  isCheckingBackground = true;
  try {
    const primaryBase = await getApiBaseUrl();
    const serverCandidates = getCandidateServerUrls(primaryBase);
    for (const base of serverCandidates) {
      try {
        const resp = await fetch(`${base}/api/check?machine_id=${encodeURIComponent(machineId)}`, {
          cache: 'no-store',
          signal: AbortSignal.timeout(2500),
        });
        if (!resp.ok) continue;
        const data = await resp.json();
        const isExplicitRevoked = Boolean(
          data.status === 'revoked' || 
          data.isRevoked === true || 
          data.action === 'FORCE_REVOKE'
        );
        const isSuspended = Boolean(data.status === 'suspended' || data.isSuspended === true);

        if (isExplicitRevoked || isSuspended) {
          console.warn('[Cache Sync] 🚨 Bản quyền đã bị thu hồi hoặc ngắt máy!');
          await chrome.storage.local.set({
            isRevoked: isExplicitRevoked,
            isSuspended,
            isVip: false,
            isRunning: false,
            isScheduleActive: false,
            autoScheduleEnabled: false,
            scheduledJobs: [],
            postJobState: 'REVOKED_STOPPED',
          });
          await chrome.storage.local.remove(['signedToken', 'licenseKey', 'licenseData', 'isVip', 'currentLicense', 'licenseInfo']);
          if (typeof FbRunner !== 'undefined' && typeof FbRunner.stopBatchPosting === 'function') {
            await FbRunner.stopBatchPosting();
          }
          if (typeof AlarmsManager !== 'undefined' && typeof AlarmsManager.stopKeepAlive === 'function') {
            await AlarmsManager.stopKeepAlive();
          }
          chrome.alarms.clearAll(() => {});
          shouldStop = true;
          isRunning = false;
          stopKeepAlive();
          if (activeTabId) {
            chrome.tabs.remove(activeTabId).catch(() => {});
            activeTabId = null;
          }

          // Bắn tín hiệu ngắt máy tới toàn bộ Tabs & Dashboard
          try {
            if (chrome.tabs && chrome.tabs.query) {
              chrome.tabs.query({}).then((tabs) => {
                tabs.forEach((tab) => {
                  if (tab.id) {
                    chrome.tabs.sendMessage(tab.id, {
                      action: 'FORCE_REVOKE_STOP',
                      message: data.message || '🚨 Bản quyền của máy tính này đã bị Quản trị viên thu hồi và ngắt kết nối!',
                    }).catch(() => {});
                  }
                });
              }).catch(() => {});
            }
          } catch (e) {}

          return {
            isValid: false,
            isActivated: false,
            isRevoked: isExplicitRevoked,
            isSuspended,
            message: data.message || '🚨 Bản quyền đã bị Quản trị viên thu hồi và ngắt máy!',
            license: null,
          };
        }

        // Nếu máy chưa kích hoạt (máy mới hoặc đang chờ duyệt đơn), KHÔNG BAO GIỜ khóa máy
        if (!data.success || data.status !== 'active') {
          await chrome.storage.local.set({
            isRevoked: false,
            isSuspended: false,
            isVip: false,
            licenseStatus: data.status || 'unregistered',
          });
          return {
            isValid: false,
            isActivated: false,
            isRevoked: false,
            isSuspended: false,
            status: data.status || 'unregistered',
            message: data.message || 'Thiết bị chưa kích hoạt bản quyền.',
            license: null,
          };
        }
        if (data.success && data.status === 'active') {
          const expMs = new Date(data.expires_at).getTime();
          const daysLeft = !isNaN(expMs) && expMs > Date.now()
            ? Math.max(1, Math.ceil((expMs - Date.now()) / (24 * 60 * 60 * 1000)))
            : (data.days_left || 0);

          const freshLic = {
            key: data.license_key || data.token || token || 'GLFB-VIP-ACTIVE',
            expiresAt: data.expires_at,
            clientName: data.client_name || 'Khách Kích Hoạt',
            notes: data.pkg_name || 'Bản quyền VIP Gia Long',
            daysLeft,
            lastVerifiedAt: Date.now(),
          };
          await chrome.storage.local.set({
            lastCheckedAt: Date.now(),
            expiresAt: data.expires_at,
            signedToken: data.token || token,
            licenseKey: data.license_key || data.token || token,
            cachedPkgName: data.pkg_name,
            isVip: true,
            licenseStatus: 'active',
            isRevoked: false,
            isSuspended: false,
            licenseData: freshLic,
          });
          return {
            isValid: true,
            isActivated: true,
            message: `✓ Bản quyền VIP đang hoạt động (Còn ${daysLeft} ngày)`,
            license: freshLic,
          };
        }
      } catch (e) {}
    }
  } finally {
    isCheckingBackground = false;
  }
  return null;
}

// Xử lý gửi đơn đặt mua gói bản quyền tự động lên Server
// Ưu tiên phản hồi tức thì (< 200ms) qua Cloudflare Pages Edge API sản xuất
async function handleCreateOrder(payload) {
  // Đảm bảo tuyệt đối mã máy luôn hợp lệ, không bao giờ gửi chuỗi 'Đang lấy...'
  if (!payload.deviceId || payload.deviceId === 'Đang lấy...' || payload.deviceId.trim() === '') {
    payload.deviceId = await getOrCreateDeviceId();
  }
  if (!payload.id) {
    payload.id = 'ord_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
  }

  const primaryBase = await getApiBaseUrl();
  const candidates = await getAllServerCandidates(primaryBase);

  // Hàm gửi đơn tới một endpoint với timeout an toàn hơn (6 giây)
  async function postOrderTo(url) {
    if (!url || !url.startsWith('http')) return null;
    const base = url.replace(/\/+$/, '');
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6000);
    try {
      const resp = await fetch(`${base}/api/orders/create`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        signal: controller.signal,
      });
      clearTimeout(timeoutId);
      if (resp.ok) {
        const text = await resp.text();
        if (text && (text.trim().startsWith('{') || text.trim().startsWith('['))) {
          const data = JSON.parse(text);
          if (data && data.success) {
            console.log('[Gia Long - FB Background] ✓ Đã gửi đơn thành công lên:', base);
            return { base, order: data.order, message: data.message };
          }
        }
      }
    } catch (err) {
      clearTimeout(timeoutId);
    }
    return null;
  }

  // Gửi song song đến TẤT CẢ các máy chủ khả dụng (Pages.dev, Cloud Run, Localhost)
  const allUrls = [primaryBase, ...candidates].filter((u, i, arr) => u && arr.indexOf(u) === i);
  let orderResult = null;
  const results = await Promise.allSettled(allUrls.map((u) => postOrderTo(u)));
  for (const r of results) {
    if (r.status === 'fulfilled' && r.value) {
      if (!orderResult) orderResult = r.value;
    }
  }

  // Bắn tín hiệu đơn mới tức thì tới tất cả các Tab Quản Trị đang mở
  try {
    if (chrome.tabs && chrome.tabs.query) {
      chrome.tabs.query({}).then((tabs) => {
        tabs.forEach((tab) => {
          if (tab.id) {
            chrome.tabs.sendMessage(tab.id, {
              action: 'DISPATCH_NEW_ORDER_TO_WEBAPP',
              order: payload,
            }).catch(() => {});
          }
        });
      }).catch(() => {});
    }
  } catch (e) {}

  // ĐỒNG THỜI: Đẩy trực tiếp 2 kênh sang Webhook Google Drive / Google Sheet nếu có
  try {
    const st = await chrome.storage.local.get(['googleDriveSheetWebhookUrl']);
    let gdriveUrl = st.googleDriveSheetWebhookUrl;
    if (!gdriveUrl) {
      try {
        const sResp = await fetch(`${primaryBase}/api/settings`, { signal: AbortSignal.timeout(2000) });
        if (sResp.ok) {
          const sData = await sResp.json();
          if (sData?.settings?.googleDriveSheetWebhookUrl) {
            gdriveUrl = sData.settings.googleDriveSheetWebhookUrl;
            await chrome.storage.local.set({ googleDriveSheetWebhookUrl: gdriveUrl });
          }
        }
      } catch (e) {}
    }
    if (gdriveUrl && gdriveUrl.startsWith('http')) {
      fetch(gdriveUrl, {
        method: 'POST',
        mode: 'no-cors',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          event: 'ORDER_UPDATE',
          id: payload.id,
          timestamp: new Date().toISOString(),
          timeFormatted: new Date().toLocaleString('vi-VN', { timeZone: 'Asia/Ho_Chi_Minh' }),
          clientName: payload.clientName || 'Khách Đặt Mua (Extension)',
          phone: payload.phone || '',
          pkgName: payload.pkgName || '',
          price: payload.price || '',
          deviceId: payload.deviceId || '',
          status: 'pending',
          note: payload.note || '',
          source: 'Gia Long FB Extension (Trực Tiếp Khách Hàng)',
        }),
      }).catch(() => {});
      console.log('[Gia Long - FB Background] ✓ Đã gửi đơn đồng thời sang Google Drive Webhook:', gdriveUrl);
    }
  } catch (e) {}

  const createdOrder = orderResult?.order || {
    id: payload.id,
    pkgName: payload.pkgName || 'Gói Bản Quyền',
    price: payload.price || '1.000.000đ',
    clientName: payload.clientName || 'Khách Đặt Mua',
    phone: payload.phone || '',
    deviceId: payload.deviceId,
    createdAt: new Date().toISOString(),
    status: 'pending',
    note: payload.note || '',
  };

  // Đồng bộ chạy ngầm sang các Tab Web Quản Trị đang mở (không chặn response UI)
  setTimeout(() => {
    try {
      if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.query) {
        chrome.tabs.query({}).then((openTabs) => {
          for (const tab of openTabs) {
            if (tab.id && tab.url && tab.url.startsWith('http')) {
              chrome.tabs.sendMessage(tab.id, {
                action: 'DISPATCH_NEW_ORDER_TO_WEBAPP',
                order: createdOrder,
              }).catch(() => {});
            }
          }
        }).catch(() => {});
      }
    } catch (e) {}
  }, 10);

  // Khởi động Fast Polling ngay khi gửi đơn thành công (3s/lần trong 5 phút)
  startFastLicensePolling(payload.deviceId, 300);

  return { 
    success: true, 
    order: createdOrder, 
    message: '✓ Đã gửi yêu cầu đề xuất mua bản quyền tới Quản trị viên thành công!' 
  };
}

async function checkLicenseStatus(forceRemote = false) {
  try {
    const data = await chrome.storage.local.get([
      'licenseKey', 
      'licenseData', 
      'gialong_customer_phone',
      'signedToken',
      'licenseStatus',
      'expiresAt',
      'lastCheckedAt',
      'isRevoked',
      'cachedPkgName'
    ]);
    const deviceId = await getOrCreateDeviceId();
    const phone = data.gialong_customer_phone || '';
    const now = Date.now();

    // 0. Nếu máy đã bị đánh dấu thu hồi: Ngắt ngay
    if (data.isRevoked) {
      return {
        isValid: false,
        isActivated: false,
        isRevoked: true,
        message: '🚨 Thiết bị đã bị Quản trị viên thu hồi bản quyền và ngắt máy!',
        license: null,
      };
    }

    // 1. CHẾ ĐỘ LƯU CACHE THÔNG MINH (DÙNG HÀNG NGÀY - 100% MIỄN PHÍ REQUEST)
    // Đọc token đã ký từ bộ nhớ máy (chrome.storage.local).
    // Nếu token còn hạn, cho chạy ngay lập tức. Sau mỗi 60 phút mới kiểm tra lại ngầm.
    const token = data.signedToken;
    const expiresAt = data.expiresAt;
    const lastChecked = data.lastCheckedAt || 0;

    if (token && data.licenseStatus === 'active' && expiresAt) {
      // Xác minh chữ ký Ed25519 trước khi tin tưởng cache (chống sửa tay trong DevTools / storage)
      if (typeof self !== 'undefined' && typeof self.verifyEd25519LicenseToken === 'function') {
        const verifyRes = await self.verifyEd25519LicenseToken(token, deviceId, lastChecked);
        if (!verifyRes.valid) {
          console.warn('[Security] Chữ ký Token Ed25519 không hợp lệ hoặc đã bị sửa đổi:', verifyRes.error);
          await chrome.storage.local.remove(['signedToken', 'licenseKey', 'licenseData', 'isVip', 'currentLicense', 'licenseInfo']);
          return {
            isValid: false,
            isActivated: false,
            message: verifyRes.error || 'Chữ ký bản quyền không hợp lệ (Dữ liệu đã bị sửa đổi)!',
            license: null,
          };
        }
      }

      const expMs = new Date(expiresAt).getTime();
      const isExpired = !isNaN(expMs) && expMs < now;

      if (!isExpired) {
        const daysLeft = Math.max(1, Math.ceil((expMs - now) / (24 * 60 * 60 * 1000)));
        const licObj = data.licenseData || {
          key: token,
          expiresAt,
          notes: data.cachedPkgName || 'Bản quyền VIP Gia Long',
          daysLeft,
          lastVerifiedAt: now,
        };

        // Nếu yêu cầu forceRemote hoặc cache đã quá 5 giây: Xác thực ngay với Server để cập nhật tức thì
        if (forceRemote || (now - lastChecked >= 5 * 1000)) {
          const freshServerStatus = await checkServerBackground(deviceId, token);
          if (freshServerStatus) {
            return freshServerStatus;
          }
        }

        return {
          isValid: true,
          isActivated: true,
          message: `✓ Bản quyền VIP đang hoạt động (Còn ${daysLeft} ngày)`,
          license: { ...licObj, daysLeft, isExpired: false },
        };
      }
    }

    const key = data.licenseKey;

    if (!key) {
      // Thử gọi /api/check theo mã máy
      const primaryBase = await getApiBaseUrl();
      const serverCandidates = getCandidateServerUrls(primaryBase);
      for (const baseUrl of serverCandidates) {
        try {
          const resp = await fetch(`${baseUrl}/api/check?machine_id=${encodeURIComponent(deviceId)}`, {
            cache: 'no-store',
            signal: AbortSignal.timeout(2500),
          });
          if (!resp.ok) continue;
          const checkRes = await resp.json();
          if (checkRes && (checkRes.status === 'revoked' || checkRes.isRevoked || checkRes.status === 'suspended' || checkRes.isSuspended)) {
            await chrome.storage.local.set({
              isRevoked: Boolean(checkRes.status === 'revoked' || checkRes.isRevoked),
              isSuspended: Boolean(checkRes.status === 'suspended' || checkRes.isSuspended),
            });
            await chrome.storage.local.remove(['signedToken', 'licenseKey', 'licenseData', 'isVip', 'currentLicense', 'licenseInfo']);
            chrome.alarms.clearAll(() => {});
            return {
              isValid: false,
              isActivated: false,
              isRevoked: Boolean(checkRes.status === 'revoked' || checkRes.isRevoked),
              isSuspended: Boolean(checkRes.status === 'suspended' || checkRes.isSuspended),
              message: checkRes.message || '🚨 Bản quyền đã bị Quản trị viên thu hồi hoặc tạm khóa!',
              license: null,
            };
          }
          if (checkRes && checkRes.success && checkRes.status === 'active') {
            const cacheData = {
              signedToken: checkRes.token,
              licenseStatus: 'active',
              expiresAt: checkRes.expires_at,
              lastCheckedAt: Date.now(),
              cachedPkgName: checkRes.pkg_name,
              isVip: true,
              licenseKey: checkRes.token || 'GLFB-VIP-ACTIVE',
              isRevoked: false,
              isSuspended: false,
              licenseData: {
                key: checkRes.token || 'GLFB-VIP-ACTIVE',
                expiresAt: checkRes.expires_at,
                clientName: checkRes.client_name || 'Khách Kích Hoạt',
                notes: checkRes.pkg_name,
                daysLeft: checkRes.days_left || 30,
                lastVerifiedAt: Date.now(),
              },
            };
            await chrome.storage.local.set(cacheData);
            return {
              isValid: true,
              isActivated: true,
              message: '✓ Bản quyền VIP đã được Quản trị viên phê duyệt tự động theo thiết bị!',
              license: cacheData.licenseData,
            };
          }
        } catch (e) {}
      }

      return {
        isValid: false,
        isActivated: false,
        message: 'Chưa kích hoạt bản quyền. Vui lòng chọn gói đặt mua để Quản trị viên duyệt tự động!',
        license: null,
      };
    }

    const cached = data.licenseData;

    // 1. Dùng Cache an toàn ngắn (10 giây) để đảm bảo đồng bộ tức thì khi Quản trị viên Duyệt hoặc Thu Hồi
    if (!forceRemote && cached && cached.lastVerifiedAt && (now - cached.lastVerifiedAt < 10 * 1000)) {
      const expMs = new Date(cached.expiresAt).getTime();
      const isExpired = expMs < now;
      const daysLeft = Math.max(0, Math.ceil((expMs - now) / (24 * 60 * 60 * 1000)));

      if (!isExpired && !cached.isSuspended && !cached.isRevoked) {
        return {
          isValid: true,
          isActivated: true,
          message: 'Bản quyền VIP đang hoạt động',
          license: { ...cached, daysLeft, isExpired: false },
        };
      }
    }

    // 2. Xác thực với Máy Chủ (Server) - Thử lần lượt các máy chủ khả dụng
    const primaryBase = await getApiBaseUrl();
    const serverCandidates = getCandidateServerUrls(primaryBase);
    let networkError = null;

    for (const baseUrl of serverCandidates) {
      try {
        const resp = await fetch(`${baseUrl}/api/license/verify`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ key, deviceId }),
        });
        const text = await resp.text();
        if (!text || (!text.trim().startsWith('{') && !text.trim().startsWith('['))) continue;
        const result = JSON.parse(text);

        // Ghi nhớ máy chủ phản hồi tốt
        chrome.storage.local.set({ customApiServerUrl: baseUrl });

        const isRevoked = Boolean(result.isRevoked || result.license?.isRevoked);
        const isSuspended = Boolean(result.license?.isSuspended);
        const isForceRevoke = Boolean(result.action === 'FORCE_REVOKE' || isRevoked || result.isDeleted);

        if (result.valid && result.license && !isRevoked && !isSuspended) {
          const lic = {
            ...result.license,
            key,
            lastVerifiedAt: now,
          };
          await chrome.storage.local.set({ licenseData: lic });
          return {
            isValid: true,
            isActivated: true,
            message: result.message || 'Bản quyền hợp lệ!',
            license: lic,
          };
        } else {
          // Khi bị xóa, thu hồi hoặc không hợp lệ: LẬP TỨC XÓA SẠCH KEY, NGẮT MỌI ALARMS & DỪNG TIẾN TRÌNH
          if (isForceRevoke || !result.valid) {
            await chrome.storage.local.remove(['licenseKey', 'licenseData', 'isVip', 'currentLicense', 'licenseInfo']);
          } else {
            const lic = {
              ...(cached || {}),
              key,
              isExpired: result.isExpired || false,
              isSuspended,
              isRevoked,
              revokeReason: result.license?.revokeReason || result.message,
              lastVerifiedAt: now,
            };
            await chrome.storage.local.set({ licenseData: lic });
          }

          // Ngắt ngay toàn bộ hẹn giờ Alarms và dừng mọi tiến trình đang chạy
          chrome.alarms.clearAll(() => {});
          await chrome.storage.local.set({
            isScheduleActive: false,
            isRunning: false,
            autoScheduleEnabled: false,
            scheduledJobs: [],
            postJobState: 'REVOKED_STOPPED',
          });
          shouldStop = true;
          isRunning = false;
          stopKeepAlive();

          return {
            isValid: false,
            isActivated: false,
            isExpired: result.isExpired || false,
            isRevoked: true,
            isSuspended,
            message: result.message || '🚨 BẢN QUYỀN ĐÃ BỊ THU HỒI / XÓA KHỎI HỆ THỐNG: Mọi tiến trình đã bị chấm dứt ngay lập tức!',
            license: null,
          };
        }
      } catch (err) {
        networkError = err;
      }
    }

    // 3. Cơ chế Offline Grace Period: Cho phép tiếp tục dùng trong 24 giờ nếu rớt mạng (Tuyệt đối không áp dụng nếu bị Thu hồi hoặc Tạm khóa)
    if (cached && (now - (cached.lastVerifiedAt || 0) < 24 * 60 * 60 * 1000)) {
      const expMs = new Date(cached.expiresAt).getTime();
      if (expMs > now && !cached.isSuspended && !cached.isRevoked) {
        console.warn('[AutoRecruit License] Rớt mạng tạm thời, duy trì bản quyền trong 24h grace period.');
        return {
          isValid: true,
          isActivated: true,
          message: 'Bản quyền hợp lệ (Chế độ Ngoại Tuyến)',
          license: cached,
        };
      }
    }
    return {
      isValid: false,
      isActivated: true,
      message: 'Không thể kết nối máy chủ xác thực bản quyền!',
      license: cached || null,
    };
  } catch (err) {
    return { isValid: false, message: err.message };
  }
}

async function activateLicenseKey(rawKey) {
  if (!rawKey) return { success: false, message: 'Vui lòng nhập mã bản quyền!' };
  const key = rawKey.trim().toUpperCase();
  const deviceId = await getOrCreateDeviceId();
  const primaryBase = await getApiBaseUrl();
  const serverCandidates = getCandidateServerUrls(primaryBase);

  let lastErr = null;
  for (const baseUrl of serverCandidates) {
    try {
      const resp = await fetch(`${baseUrl}/api/license/activate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          key,
          deviceId,
          deviceName: `Browser (${deviceId.slice(-4)})`,
        }),
      });
      const text = await resp.text();
      if (!text || (!text.trim().startsWith('{') && !text.trim().startsWith('['))) continue;
      const result = JSON.parse(text);

      if (result.success && result.license) {
        const expMs = new Date(result.license.expiresAt).getTime();
        const daysLeft = !isNaN(expMs) && expMs > Date.now()
          ? Math.max(1, Math.ceil((expMs - Date.now()) / (24 * 60 * 60 * 1000)))
          : (result.license.daysLeft || 30);

        const lic = {
          ...result.license,
          key,
          daysLeft,
          lastVerifiedAt: Date.now(),
        };
        await chrome.storage.local.set({
          licenseKey: key,
          licenseData: lic,
          customApiServerUrl: baseUrl,
          expiresAt: result.license.expiresAt,
          signedToken: key,
          licenseStatus: 'active',
          isVip: true,
          isRevoked: false,
          isSuspended: false,
          lastCheckedAt: Date.now(),
          cachedPkgName: result.license.notes || (result.license.planType === 'team' ? 'Gói Doanh Nghiệp' : (result.license.planType === 'trial' ? 'Gói Dùng Thử 1N' : 'Gói VIP Cá Nhân')),
        });

        // Nếu kích hoạt gói chính thức, xóa bỏ giới hạn bài đăng dùng thử; nếu là gói dùng thử thì reset về 0
        if (result.license.planType === 'trial') {
          await chrome.storage.local.set({ trialPostsCount: 0 });
        } else {
          await chrome.storage.local.remove(['trialPostsCount']);
        }

        return { success: true, message: result.message, license: lic };
      } else {
        return { success: false, message: result.message || 'Kích hoạt mã không thành công!' };
      }
    } catch (err) {
      lastErr = err;
    }
  }
  return { success: false, message: 'Lỗi kết nối máy chủ: ' + (lastErr ? lastErr.message : 'Không thể kết nối') };
}

async function deactivateLicenseKey() {
  await chrome.storage.local.remove(['licenseKey', 'licenseData']);
  return { success: true, message: 'Đã hủy kích hoạt bản quyền trên máy này.' };
}

if (typeof self !== 'undefined') {
  self.checkLicenseStatus = checkLicenseStatus;
}

// ==========================================
// 1. CHẾ ĐỘ HẸN GIỜ ĐĂNG BÀI TỰ ĐỘNG THEO KHUNG GIỜ & TỰ CHUYỂN TÀI KHOẢN FACEBOOK
// ==========================================
async function handleSetSchedule(config = {}) {
  const licCheck = await checkLicenseStatus(false);
  if (!licCheck.isValid) {
    console.warn('[AutoRecruit Background] Không thể hẹn giờ: Chưa kích hoạt bản quyền VIP!');
    if (typeof AlarmsManager !== 'undefined') {
      await AlarmsManager.syncScheduleAlarms([], false);
    }
    await chrome.storage.local.set({ isScheduleActive: false });
    return {
      success: false,
      message: `Chưa kích hoạt bản quyền VIP hoặc đã hết hạn (${licCheck.message}). Không thể kích hoạt hẹn giờ tự động!`,
    };
  }

  const existing = await chrome.storage.local.get(['scheduleSlots', 'savedTimes', 'scheduledTimes']);
  const rawTimes = Array.isArray(config.times) && config.times.length > 0
    ? config.times
    : (existing.savedTimes || existing.scheduledTimes || ['08:30', '11:30', '17:30', '20:00']);
  const rawSlots = Array.isArray(config.slots) && config.slots.length > 0
    ? config.slots
    : existing.scheduleSlots;

  const normalizedSlots = (typeof SharedStorage !== 'undefined' && SharedStorage.normalizeScheduleSlots)
    ? SharedStorage.normalizeScheduleSlots(rawSlots, rawTimes)
    : rawTimes.map((t) => ({
        id: `slot_${String(t).replace(':', '_')}`,
        time: String(t),
        enabled: true,
        accountId: 'active',
        accountName: 'Tài khoản đang chọn',
        postId: 'selected',
        autoSwitchAccount: true,
        lastRunDate: null,
      }));

  const timesList = normalizedSlots.map((s) => s.time);

  if (typeof SharedStorage !== 'undefined' && SharedStorage.patch) {
    await SharedStorage.patch('scheduleSlots', () => normalizedSlots);
    await SharedStorage.patch('savedTimes', () => timesList);
  }

  await chrome.storage.local.set({
    isScheduleActive: true,
    scheduleSlots: normalizedSlots,
    savedTimes: timesList,
    scheduledTimes: timesList,
    scheduleConfigPayload: config,
  });

  if (typeof AlarmsManager !== 'undefined') {
    await AlarmsManager.initAlarms();
    await AlarmsManager.syncScheduleAlarms(normalizedSlots, true);
  }

  console.log('[AutoRecruit Background] ✓ Đã kích hoạt hẹn giờ theo khung giờ & tài khoản:', normalizedSlots);
  return {
    success: true,
    slots: normalizedSlots,
    times: timesList,
    message: 'Đã kích hoạt hẹn giờ tự động theo khung giờ thành công!',
  };
}

// BỘ LẮNG NGHE ALARMS: ĐIỀU PHỐI QUA ALARMS MANAGER (HỖ TRỢ TỰ CHUYỂN TÀI KHOẢN FB & ĐỦ 3 BIẾN THỂ)
chrome.alarms.onAlarm.addListener(async (alarm) => {
  console.log('[AutoRecruit Background] ⏰ ALARM KÍCH HOẠT:', alarm.name);
  if (typeof AlarmsManager !== 'undefined') {
    await AlarmsManager.handleAlarmTrigger(alarm);
  }
});

// TỰ ĐỘNG KHÔI PHỤC HẸN GIỜ KHI KHỞI ĐỘNG LẠI CHROME HOẶC MỞ MÁY TÍNH
async function restoreScheduleOnBoot() {
  try {
    const licCheck = await checkLicenseStatus(false);
    if (!licCheck.isValid) {
      console.log('[AutoRecruit Background] Bản quyền chưa kích hoạt -> Không khôi phục hẹn giờ.');
      if (typeof AlarmsManager !== 'undefined') {
        await AlarmsManager.syncScheduleAlarms([], false);
      }
      await chrome.storage.local.set({ isScheduleActive: false });
      return;
    }
    const data = await chrome.storage.local.get([
      'isScheduleActive',
      'scheduleSlots',
      'savedTimes',
      'scheduledTimes',
      'delaySec',
      'enableSpintax',
    ]);
    const times = data.savedTimes || data.scheduledTimes || [];
    const slots = data.scheduleSlots || [];
    if (data.isScheduleActive && (slots.length > 0 || times.length > 0)) {
      await handleSetSchedule({
        slots,
        times,
        delaySec: data.delaySec || 30,
        isSpintaxEnabled: data.enableSpintax !== false,
      });
      console.log('[AutoRecruit Background] ✓ Đã tự động nạp lại các khung giờ hẹn đăng:', slots.length || times.length);
    }
  } catch (err) {
    console.warn('[AutoRecruit Background] Lỗi khôi phục hẹn giờ:', err);
  }
}

chrome.runtime.onStartup.addListener(async () => {
  console.log('[AutoRecruit Background] Chrome vừa khởi động -> Khởi tạo dữ liệu & khôi phục trạng thái...');
  if (typeof SharedStorage !== 'undefined') await SharedStorage.runStorageMigrations();
  if (typeof AlarmsManager !== 'undefined') await AlarmsManager.initAlarms();
  if (typeof FbRunner !== 'undefined') await FbRunner.checkAndRecoverRunState();
  restoreScheduleOnBoot();
});

chrome.runtime.onInstalled.addListener(async () => {
  console.log('[AutoRecruit Background] Extension vừa nạp/cập nhật -> Chạy migration & nạp alarms...');
  if (typeof SharedStorage !== 'undefined') await SharedStorage.runStorageMigrations();
  if (typeof AlarmsManager !== 'undefined') await AlarmsManager.initAlarms();
  if (typeof FbRunner !== 'undefined') await FbRunner.checkAndRecoverRunState();
  restoreScheduleOnBoot();
});

// ==========================================
// 2. LẮNG NGHE THÔNG ĐIỆP
// ==========================================
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  // 1. BẮT ĐẦU ĐĂNG BÀI BỀN VỮNG
  if (request.action === 'START_BATCH_POSTING') {
    const payload = request.payload || request;
    const groups = payload.groups || [];
    const content = payload.content || payload.postContent || '';
    const variants = payload.variants || [];
    const images = payload.images || [];
    const isSpintaxEnabled = payload.isSpintaxEnabled !== undefined ? payload.isSpintaxEnabled : true;
    const delaySec = parseInt(payload.delaySec, 10) || 30;
    const postTitle = payload.postTitle || 'Bài Tuyển Dụng';
    const accountId = payload.accountId || null;
    const accountName = payload.accountName || null;

    if (!groups.length) {
      sendResponse({ success: false, message: 'Danh sách nhóm trống!' });
      return true;
    }

    // KIỂM TRA BẢN QUYỀN TRƯỚC KHI THỰC HIỆN ĐĂNG BÀI
    checkLicenseStatus().then(async (licCheck) => {
      if (!licCheck.isValid) {
        const errorText = `🚨 BẢN QUYỀN CHƯA KÍCH HOẠT HOẶC ĐÃ HẾT HẠN: ${licCheck.message}`;
        if (typeof FbRunner !== 'undefined') {
          await FbRunner.appendHistoryEntry({
            groupName: 'Hệ Thống Bản Quyền',
            groupLink: '',
            postTitle,
            status: 'failed',
            statusCode: 'LICENSE_INVALID',
            message: errorText,
          });
        }
        sendResponse({ success: false, message: errorText });
        return;
      }

      // KIỂM TRA HẠN MỨC GÓI DÙNG THỬ 1 NGÀY (TỐI ĐA 20 BÀI ĐĂNG)
      if (licCheck.license?.planType === 'trial') {
        const trialData = await chrome.storage.local.get(['trialPostsCount']);
        const trialPostsCount = trialData.trialPostsCount || 0;
        if (trialPostsCount >= 20) {
          const errorText = `🚨 ĐÃ HẾT HẠN MỨC DÙNG THỬ (20/20 BÀI ĐĂNG)!\n\nGói dùng thử 1 ngày đã hoàn thành tối đa 20 bài đăng. Vui lòng đặt mua Gói Bản Quyền Chính Thức để tiếp tục đăng không giới hạn!`;
          if (typeof FbRunner !== 'undefined') {
            await FbRunner.appendHistoryEntry({
              groupName: 'Gói Dùng Thử',
              groupLink: '',
              postTitle,
              status: 'failed',
              statusCode: 'TRIAL_LIMIT_REACHED',
              message: errorText,
            });
          }
          sendResponse({ success: false, message: errorText });
          return;
        }
      }

      try {
        if (typeof FbRunner !== 'undefined') {
          const startResult = await FbRunner.startBatchPosting({
            groups,
            content,
            variants,
            images,
            isSpintaxEnabled,
            delaySec,
            postTitle,
            accountId,
            accountName,
          });
          sendResponse({ success: true, message: 'Đã bắt đầu tiến trình đăng bài bền vững!', runId: startResult.runId });
        } else {
          sendResponse({ success: false, message: 'FbRunner chưa được nạp' });
        }
      } catch (err) {
        console.error('[AutoRecruit Background] Lỗi khởi chạy tiến trình:', err);
        sendResponse({ success: false, message: err.message || 'Lỗi khởi chạy tiến trình' });
      }
    });

    return true;
  }

  // 2. DỪNG TIẾN TRÌNH LẬP TỨC
  if (request.action === 'STOP_BATCH_POSTING') {
    console.log('[AutoRecruit Background] Nhận lệnh DỪNG TIẾN TRÌNH!');
    if (typeof FbRunner !== 'undefined') {
      FbRunner.stopBatchPosting()
        .then((res) => sendResponse(res))
        .catch((err) => sendResponse({ success: false, message: err.message }));
    } else {
      sendResponse({ success: true, message: 'Đã dừng' });
    }
    return true;
  }

  // 2.1 TRUY VẤN TRẠNG THÁI RUN STATE
  if (request.action === 'GET_RUN_STATE') {
    if (typeof FbRunner !== 'undefined') {
      FbRunner.getRunState().then((state) => sendResponse({ success: true, state }));
    } else {
      sendResponse({ success: true, state: null });
    }
    return true;
  }

  // 2.2 QUẢN LÝ TÀI KHOẢN FACEBOOK
  if (request.action === 'GET_FB_ACCOUNTS') {
    if (typeof AccountsManager !== 'undefined') {
      Promise.all([
        AccountsManager.getAccounts(),
        AccountsManager.getActiveAccount(),
      ]).then(([accounts, active]) => {
        sendResponse({ success: true, accounts, activeAccount: active });
      }).catch((err) => sendResponse({ success: false, error: err.message }));
    } else {
      sendResponse({ success: false, error: 'AccountsManager chưa sẵn sàng' });
    }
    return true;
  }

  if (request.action === 'SET_ACTIVE_FB_ACCOUNT') {
    if (typeof AccountsManager !== 'undefined') {
      AccountsManager.setActiveAccount(request.accountId)
        .then((res) => sendResponse(res))
        .catch((err) => sendResponse({ success: false, error: err.message }));
    } else {
      sendResponse({ success: false, error: 'AccountsManager chưa sẵn sàng' });
    }
    return true;
  }

  if (request.action === 'DETECT_CURRENT_FB_ACCOUNT_FROM_TAB') {
    if (typeof AccountsManager !== 'undefined') {
      AccountsManager.detectCurrentAccountFromTab()
        .then((res) => sendResponse(res))
        .catch((err) => sendResponse({ success: false, error: err.message }));
    } else {
      sendResponse({ success: false, error: 'AccountsManager chưa sẵn sàng' });
    }
    return true;
  }

  if (request.action === 'REMOVE_FB_ACCOUNT') {
    if (typeof AccountsManager !== 'undefined') {
      AccountsManager.removeAccount(request.accountId)
        .then((res) => sendResponse(res))
        .catch((err) => sendResponse({ success: false, error: err.message }));
    } else {
      sendResponse({ success: false, error: 'AccountsManager chưa sẵn sàng' });
    }
    return true;
  }

  // 3. Cài đặt hẹn giờ
  if (request.action === 'SCHEDULE_AUTO_POST') {
    handleSetSchedule(request.payload || request)
      .then((res) => sendResponse(res))
      .catch((err) => sendResponse({ success: false, message: err.message }));
    return true;
  }

  // 4. Hủy hẹn giờ
  if (request.action === 'CANCEL_SCHEDULE') {
    const clearPromise = (typeof AlarmsManager !== 'undefined' && AlarmsManager.syncScheduleAlarms)
      ? AlarmsManager.syncScheduleAlarms([], false)
      : Promise.resolve();
    clearPromise.then(() => {
      chrome.storage.local.set({ isScheduleActive: false });
      sendResponse({ success: true });
    });
    return true;
  }

  // 4.1 Gửi đơn đặt mua gói bản quyền trực tuyến lên Server Quản Trị
  if (request.action === 'CREATE_ORDER') {
    handleCreateOrder(request.payload || {})
      .then((res) => sendResponse(res))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true;
  }

  // 4.2 Thiết lập URL máy chủ hiện hành
  if (request.action === 'SET_SERVER_URL' && request.url) {
    const cleanUrl = String(request.url).trim().replace(/\/+$/, '');
    chrome.storage.local.get(['known_server_urls'], (res) => {
      const list = Array.isArray(res.known_server_urls) ? res.known_server_urls : [];
      if (!list.includes(cleanUrl)) list.push(cleanUrl);
      chrome.storage.local.set({
        customApiServerUrl: cleanUrl,
        webapp_last_url: cleanUrl,
        lastSyncedFromUrl: cleanUrl,
        known_server_urls: list,
      });
      console.log('[Gia Long - FB] ✓ Đã nhận và kết nối với máy chủ Web App:', cleanUrl);
    });
    sendResponse({ success: true, url: cleanUrl });
    return true;
  }

  // 5. Đồng bộ thời gian thực từ Web App (pages.dev)
  if (request.action === 'REALTIME_WEBAPP_SYNC' || request.action === 'SYNC_FROM_WEBAPP_PAGE') {
    // Kiểm tra sender an toàn: chỉ nhận từ runtime nội bộ và domain production chính thức
    const senderUrl = sender?.url || '';
    const isAllowedSender = (!sender?.id || sender.id === chrome.runtime.id) &&
      (!senderUrl || senderUrl.startsWith('https://gia-long---tuy-n-d-ng.pages.dev'));
    if (!isAllowedSender) {
      console.warn('[Background Security] Từ chối REALTIME_WEBAPP_SYNC từ nguồn lạ:', senderUrl);
      sendResponse({ success: false, error: 'Nguồn gửi không được phép!' });
      return true;
    }

    // Không được ghi đè bài viết / nhóm khi đang có tiến trình chạy bài
    if (activeTabId !== null || isRunning) {
      console.warn('[Background Security] Đang trong tiến trình đăng bài, hoãn đồng bộ bài viết/nhóm để tránh xung đột!');
      sendResponse({ success: false, message: 'Đang chạy đăng bài, tạm thời không ghi đè!' });
      return true;
    }

    const { posts, groups, settings, activePost, url, googleDriveWebhookUrl } = request.payload || {};
    if (posts && posts.length) {
      const targetPost = activePost || posts.find((p) => p.status === 'active') || posts[0];
      const hasImage = !!(targetPost?.images && targetPost.images.length > 0 && targetPost.images[0]);
      const gdriveUrl = googleDriveWebhookUrl || settings?.googleDriveSheetWebhookUrl;
      const toSet = {
        isInitialized: true,
        savedPosts: posts || [],
        savedGroups: (groups && groups.length > 0) ? groups : [],
        savedTimes: (settings && settings.postTimes) ? settings.postTimes : ['08:30', '11:30', '17:30', '20:00'],
        attachedImageUrl: targetPost?.images?.[0] || '',
        attachedImages: (targetPost?.images || []).slice(0, 3),
        customPostText: targetPost?.content || '',
        isAttachImageEnabled: hasImage,
        lastSyncedFromUrl: url || 'https://gia-long---tuy-n-d-ng.pages.dev',
        lastSyncTimestamp: Date.now(),
      };
      if (gdriveUrl && typeof gdriveUrl === 'string' && gdriveUrl.startsWith('http')) {
        toSet.googleDriveSheetWebhookUrl = gdriveUrl.trim();
      }
      chrome.storage.local.set(toSet);
      console.log('[AutoRecruit Background] ✓ Đã nhận dữ liệu đồng bộ an toàn từ Web App');
    }
    sendResponse({ success: true });
    return true;
  }

  // 6. DÒ TÌM NHÓM FACEBOOK THEO TỪ KHÓA & THÀNH VIÊN
  if (request.action === 'SEARCH_AND_SCAN_GROUPS') {
    handleSearchGroups(request.payload || {})
      .then((res) => sendResponse(res))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true;
  }

  // 7. TỰ ĐỘNG THAM GIA CÁC NHÓM ĐÃ CHỌN VÀ THÊM VÀO DANH SÁCH ĐĂNG BÀI
  if (request.action === 'JOIN_AND_ADD_GROUPS') {
    handleBatchJoinAndAddGroups(request.payload || {})
      .then((res) => sendResponse(res))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true;
  }

  // 8. KIỂM TRA BẢN QUYỀN (LICENSE VERIFY)
  if (request.action === 'CHECK_LICENSE') {
    checkLicenseStatus(request.forceRemote || false)
      .then((res) => sendResponse(res))
      .catch((err) => sendResponse({ isValid: false, message: err.message }));
    return true;
  }

  // 9. KÍCH HOẠT MÃ BẢN QUYỀN (LICENSE ACTIVATE)
  if (request.action === 'ACTIVATE_LICENSE') {
    activateLicenseKey(request.key || request.licenseKey)
      .then((res) => sendResponse(res))
      .catch((err) => sendResponse({ success: false, message: err.message }));
    return true;
  }

  // 10. HỦY KÍCH HOẠT MÃ TRÊN MÁY NÀY
  if (request.action === 'DEACTIVATE_LICENSE') {
    deactivateLicenseKey()
      .then((res) => sendResponse(res))
      .catch((err) => sendResponse({ success: false, message: err.message }));
    return true;
  }

  // 11. LẤY MÃ ĐỊNH DANH THIẾT BỊ (DEVICE ID)
  if (request.action === 'GET_DEVICE_ID') {
    getOrCreateDeviceId()
      .then((deviceId) => sendResponse({ success: true, deviceId }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true;
  }

  // 12. TẢI LẠI & ĐỒNG BỘ QUẢN TRỊ (KÉO TRẠNG THÁI DUYỆT ĐƠN & KEY MỚI NHẤT TỪ SERVER)
  if (request.action === 'SYNC_ADMIN_STATUS' || request.action === 'FETCH_MY_ORDERS') {
    fetchMyOrdersAndSync()
      .then((res) => sendResponse(res))
      .catch((err) => sendResponse({ success: false, message: err.message }));
    return true;
  }

  // 13. NGẮT MÁY KHẨN CẤP TỪ WEB APP / ADMIN (FORCE REVOKE)
  if (request.action === 'FORCE_REVOKE_DEVICE') {
    chrome.storage.local.set({
      isRevoked: true,
      isVip: false,
      isRunning: false,
      isScheduleActive: false,
      autoScheduleEnabled: false,
      scheduledJobs: [],
      postJobState: 'REVOKED_STOPPED',
    }).then(() => {
      chrome.storage.local.remove(['signedToken', 'licenseKey', 'licenseData', 'isVip', 'currentLicense', 'licenseInfo']);
      chrome.alarms.clearAll(() => {});
      shouldStop = true;
      isRunning = false;
      stopKeepAlive();
      if (activeTabId) {
        chrome.tabs.remove(activeTabId).catch(() => {});
        activeTabId = null;
      }
      sendResponse({ success: true, message: 'Đã ngắt máy lập tức!' });
    });
    return true;
  }
});

// Tra cứu danh sách đơn hàng của máy khách và tự động kích hoạt key nếu đã được Admin duyệt
async function fetchMyOrdersAndSync() {
  const deviceId = await getOrCreateDeviceId();
  const primaryBase = await getApiBaseUrl();
  const serverCandidates = getCandidateServerUrls(primaryBase);

  for (const baseUrl of serverCandidates) {
    try {
      const resp = await fetch(`${baseUrl}/api/orders/my-orders?deviceId=${encodeURIComponent(deviceId)}`);
      const text = await resp.text();
      if (!text || (!text.trim().startsWith('{') && !text.trim().startsWith('['))) continue;
      const data = JSON.parse(text);
      if (data && data.success && Array.isArray(data.orders)) {
        await chrome.storage.local.set({ myOrders: data.orders, lastOrdersSync: Date.now() });

        // 🚨 NẾU THIẾT BỊ BỊ THU HỒI / NGẮT MÁY VÀ KHÔNG CÓ BẢN QUYỀN MỚI
        const hasActiveOrderOrLicense = Boolean(
          data.activeLicense || 
          data.orders.some((o) => o.status === 'approved' && o.generatedKey)
        );
        if (data.isRevoked && !hasActiveOrderOrLicense) {
          console.warn('[AutoRecruit Background] 🚨 Đơn hàng của máy này đã bị thu hồi / ngắt kết nối!');
          await chrome.storage.local.set({
            isRevoked: true,
            isVip: false,
            isRunning: false,
            isScheduleActive: false,
            autoScheduleEnabled: false,
            scheduledJobs: [],
            postJobState: 'REVOKED_STOPPED',
          });
          await chrome.storage.local.remove(['signedToken', 'licenseKey', 'licenseData', 'isVip', 'currentLicense', 'licenseInfo']);
          chrome.alarms.clearAll(() => {});
          shouldStop = true;
          isRunning = false;
          stopKeepAlive();
          if (activeTabId) {
            chrome.tabs.remove(activeTabId).catch(() => {});
            activeTabId = null;
          }
          return { success: false, isRevoked: true, message: 'Bản quyền đã bị thu hồi' };
        }

        // Tự động kích hoạt mã nếu có đơn được phê duyệt
        const approvedOrder = data.orders.find((o) => o.status === 'approved' && o.generatedKey);
        if (approvedOrder && approvedOrder.generatedKey) {
          const currentData = await chrome.storage.local.get(['licenseKey', 'isRevoked']);
          if (!currentData.isRevoked && (!currentData.licenseKey || currentData.licenseKey !== approvedOrder.generatedKey)) {
            console.log('[AutoRecruit Background] Phát hiện đơn đã được duyệt, tự động nạp key:', approvedOrder.generatedKey);
            await activateLicenseKey(approvedOrder.generatedKey);
          }
        }

        const licRes = await checkLicenseStatus(true);
        return {
          success: true,
          orders: data.orders,
          totalPending: data.totalPending || 0,
          license: licRes.license,
          isValid: licRes.isValid,
          message: '✓ Đã đồng bộ trạng thái đơn hàng & bản quyền từ máy chủ Quản trị thành công!',
        };
      }
    } catch (e) {}
  }
  return { success: false, message: 'Không thể kết nối đến máy chủ Quản trị!' };
}

// Chuyển URL ảnh thành DataURL trực tiếp trong Background Service Worker (Không dùng FileReader)
async function urlToDataUrl(url) {
  if (!url) return '';
  if (url.startsWith('data:')) return url;
  try {
    const res = await fetch(url);
    const blob = await res.blob();
    const buffer = await blob.arrayBuffer();
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    const base64 = btoa(binary);
    const mime = blob.type || 'image/jpeg';
    return `data:${mime};base64,${base64}`;
  } catch (err) {
    console.warn('[AutoRecruit Background] Lỗi nạp URL ảnh:', err);
    return url;
  }
}

// BIẾN THỂ NỘI DUNG TỰ ĐỘNG CHỐNG THUẬT TOÁN QUÉT TRÙNG LẶP CỦA FACEBOOK
// Giữ nguyên vẹn 100% nội dung chính của bài viết, chỉ áp dụng ký tự vô hình để tránh FB check trùng lặp
function generateAutoVariant(baseText, variantIdx) {
  if (!baseText || typeof baseText !== 'string') return '';
  if (variantIdx === 0) {
    return baseText;
  } else if (variantIdx === 1) {
    return baseText + '\u200B\u200C';
  } else {
    return baseText + '\uFEFF\u200D';
  }
}

// Xử lý biến thể xoay vòng xen kẽ 3 loại nội dung kèm Spintax {A|B|C}
function generateShuffledContent(text, index, isSpintaxEnabled, variants = []) {
  if (!text) return '';
  const variantIdx = index % 3; // 0, 1, 2 xen kẽ cho từng nhóm
  let chosenText = text;

  if (variants && Array.isArray(variants) && variants.length === 3 && variants[variantIdx] && variants[variantIdx].trim()) {
    chosenText = variants[variantIdx];
  } else {
    chosenText = generateAutoVariant(text, variantIdx);
  }

  if (!isSpintaxEnabled) {
    return chosenText.replace(/\{([^{}]+)\}/g, (m, c) => c.split('|')[0]);
  }
  return chosenText.replace(/\{([^{}]+)\}/g, (match, choices) => {
    const parts = choices.split('|');
    return parts[Math.floor(Math.random() * parts.length)];
  });
}

function shuffleArray(array) {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

// TIẾN TRÌNH ĐĂNG LIÊN HOÀN CÁC NHÓM (HỖ TRỢ 3 BIẾN THỂ XEN KẼ & CHẶN SPAM)
async function runBatchPosting(
  groups,
  baseContent,
  images,
  isSpintaxEnabled,
  delaySec,
  shouldShuffle = true,
  runType = 'manual',
  postTitle = '',
  variants = []
) {
  let groupsToRun = groups;
  if (shouldShuffle && groups.length > 1) {
    groupsToRun = shuffleArray(groups);
    console.log('[AutoRecruit Background] 🎲 Đã trộn ngẫu nhiên thứ tự', groupsToRun.length, 'nhóm.');
  }

  // Tiền xử lý chuyển đổi tất cả ảnh thành base64 DataURL trong background trước khi gửi sang content
  let processedImages = [];
  if (images && images.length > 0) {
    const rawList = images.slice(0, 3);
    for (let j = 0; j < rawList.length; j++) {
      if (rawList[j]) {
        try {
          const dataUrl = await urlToDataUrl(rawList[j]);
          if (dataUrl) processedImages.push(dataUrl);
        } catch (imgErr) {
          console.warn('Lỗi nạp ảnh nền:', imgErr);
        }
      }
    }
  }

  for (let i = 0; i < groupsToRun.length; i++) {
    if (shouldStop) break;

    // Kiểm tra bản quyền nghiêm ngặt trước mỗi nhóm đăng
    const runtimeLicCheck = await checkLicenseStatus(true);
    if (!runtimeLicCheck.isValid || runtimeLicCheck.isRevoked) {
      console.warn('[AutoRecruit Background] 🚨 Bản quyền bị thu hồi hoặc ngắt máy trong lúc đăng bài:', runtimeLicCheck.message);
      shouldStop = true;
      isRunning = false;
      stopKeepAlive();
      if (activeTabId) {
        chrome.tabs.remove(activeTabId).catch(() => {});
        activeTabId = null;
      }
      chrome.alarms.clearAll(() => {});
      await updateStatus({
        isRunning: false,
        currentIndex: i,
        totalGroups: groupsToRun.length,
        statusText: `🚨 TIẾN TRÌNH ĐÃ BỊ DỪNG: ${runtimeLicCheck.message || 'Bản quyền bị thu hồi'}`,
      });
      await addHistoryEntry({
        groupName: 'Hệ Thống Bản Quyền',
        groupLink: '',
        postTitle: postTitle || 'Bản Quyền',
        status: 'failed',
        type: runType,
        message: `🚨 Ngắt máy ngay lập tức: ${runtimeLicCheck.message || 'Bản quyền bị thu hồi'}`,
      });
      break;
    }

    const group = groupsToRun[i];
    const groupContent = generateShuffledContent(baseContent, i, isSpintaxEnabled, variants);

    let groupUrl = group.link;
    if (!groupUrl.startsWith('http')) {
      groupUrl = `https://www.facebook.com/groups/${groupUrl.replace(/^groups\//, '')}/`;
    }

    await updateStatus({
      isRunning: true,
      currentIndex: i + 1,
      totalGroups: groupsToRun.length,
      currentGroupName: group.name,
      statusText: `Đang mở nhóm ${i + 1}/${groupsToRun.length}: ${group.name}...`,
    });

    let tab = null;
    let postSuccess = false;
    let errorMsg = '';
    let isSpamDetected = false;

    try {
      tab = await chrome.tabs.create({ url: groupUrl, active: true });
      activeTabId = tab.id;

      // Chờ trang Facebook tải xong
      for (let w = 0; w < 12; w++) {
        if (shouldStop) break;
        try {
          const t = await chrome.tabs.get(tab.id);
          if (t.status === 'complete') break;
        } catch (e) {}
        await interruptibleSleep(1000);
      }
      await interruptibleSleep(2500);

      if (shouldStop) {
        if (tab?.id) chrome.tabs.remove(tab.id).catch(() => {});
        break;
      }

      await updateStatus({
        isRunning: true,
        currentIndex: i + 1,
        totalGroups: groupsToRun.length,
        currentGroupName: group.name,
        statusText: `Đang điền nội dung (Biến thể ${(i % 3) + 1}/3) & ảnh vào: ${group.name}...`,
      });

      // Gửi lệnh sang content script kèm cơ chế thử lại nếu script đang được nạp
      let response = null;
      for (let retry = 0; retry < 5; retry++) {
        if (shouldStop) break;
        try {
          response = await chrome.tabs.sendMessage(tab.id, {
            action: 'AUTO_POST_TO_GROUP',
            content: groupContent,
            images: processedImages.length > 0 ? processedImages : (images || []),
          });
          if (response) break;
        } catch (msgErr) {
          console.log(`[AutoRecruit Background] Đang đợi content script nạp (lần ${retry + 1}/5)...`);
          if (retry === 2) {
            try {
              await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                files: ['content.js'],
              });
            } catch (injErr) {}
          }
          await interruptibleSleep(2000);
        }
      }

      postSuccess = !!(response && response.success);
      if (!postSuccess) errorMsg = response?.error || 'Không thể bấm nút Đăng bài';

      // Kiểm tra mọi dấu hiệu Facebook chặn spam / giới hạn tần suất
      const lowerErr = (errorMsg || '').toLowerCase();
      isSpamDetected = !!(
        response?.isSpamBlocked ||
        lowerErr.includes('giới hạn tần suất') ||
        lowerErr.includes('bảo vệ cộng đồng') ||
        lowerErr.includes('chặn spam') ||
        lowerErr.includes('thao tác quá nhanh') ||
        lowerErr.includes('temporarily blocked') ||
        lowerErr.includes('protect the community') ||
        lowerErr.includes('limit how often') ||
        lowerErr.includes('thử lại sau')
      );

      if (tab?.id) {
        chrome.tabs.remove(tab.id).catch(() => {});
        activeTabId = null;
      }
    } catch (err) {
      errorMsg = err.message || 'Lỗi mạng hoặc tải trang';
      console.error('[AutoRecruit Background] Lỗi nhóm:', group.name, err);
      const lowerErr = (errorMsg || '').toLowerCase();
      if (
        lowerErr.includes('giới hạn tần suất') ||
        lowerErr.includes('bảo vệ cộng đồng') ||
        lowerErr.includes('chặn spam') ||
        lowerErr.includes('thao tác quá nhanh') ||
        lowerErr.includes('temporarily blocked')
      ) {
        isSpamDetected = true;
      }
      if (tab?.id) {
        chrome.tabs.remove(tab.id).catch(() => {});
        activeTabId = null;
      }
    }

    // 🚨 NẾU PHÁT HIỆN FACEBOOK GIỚI HẠN TẦN SUẤT: DỪNG TỨC THÌ 100% VÀ NGẮT TOÀN BỘ HÀNG ĐỢI!
    if (isSpamDetected) {
      shouldStop = true;
      isRunning = false;
      stopKeepAlive();
      console.warn('[AutoRecruit Background] 🚨 FACEBOOK ACTION BLOCK DETECTED -> IMMEDIATE EMERGENCY HALT!');

      const alertData = {
        isBlocked: true,
        detectedAt: new Date().toISOString(),
        groupName: group.name,
        error: errorMsg || 'Facebook giới hạn tần suất bạn đăng bài để bảo vệ cộng đồng khỏi spam.',
        advice: 'Hệ thống đã tự động dừng khẩn cấp toàn bộ tiến trình để bảo vệ an toàn tuyệt đối cho tài khoản. Vui lòng cho tài khoản nghỉ ngơi (sau tối thiểu 4 - 6 tiếng).'
      };
      await chrome.storage.local.set({ fbSpamWarningAlert: alertData });

      await addHistoryEntry({
        groupName: group.name,
        groupLink: group.link,
        postTitle: postTitle || 'Bài Tuyển Dụng',
        status: 'failed',
        type: runType,
        message: `🚨 ${errorMsg || 'Facebook giới hạn tần suất'}. [ĐÃ TỰ ĐỘNG DỪNG TOÀN BỘ TIẾN TRÌNH]`,
      });

      await updateStatus({
        isRunning: false,
        currentIndex: i + 1,
        totalGroups: groupsToRun.length,
        statusText: '🚨 ĐÃ TỰ ĐỘNG DỪNG KHẨN CẤP: Facebook cảnh báo giới hạn tần suất! Đã dừng toàn bộ hàng đợi.',
      });

      break; // DỪNG NGAY LẬP TỨC! KHÔNG ĐĂNG THÊM BẤT KỲ NHÓM NÀO KHÁC!
    }

    // Theo dõi và giới hạn số bài đăng của gói dùng thử (20 bài)
    let trialLimitReached = false;
    let trialPostCountText = '';
    if (postSuccess) {
      try {
        const licRes = await checkLicenseStatus();
        if (licRes?.license?.planType === 'trial') {
          const trialData = await chrome.storage.local.get(['trialPostsCount']);
          const currentTrialCount = (trialData.trialPostsCount || 0) + 1;
          await chrome.storage.local.set({ trialPostsCount: currentTrialCount });
          trialPostCountText = ` [Dùng Thử: ${currentTrialCount}/20 bài]`;

          if (currentTrialCount >= 20) {
            trialLimitReached = true;
            shouldStop = true;
          }
        }
      } catch (tErr) {}
    }

    await addHistoryEntry({
      groupName: group.name,
      groupLink: group.link,
      postTitle: postTitle || 'Bài Tuyển Dụng',
      status: postSuccess ? 'success' : 'failed',
      type: runType,
      message: postSuccess ? `Đăng thành công${trialPostCountText}` : errorMsg,
    });

    if (trialLimitReached) {
      await updateStatus({
        isRunning: false,
        currentIndex: i + 1,
        totalGroups: groupsToRun.length,
        statusText: '🎯 [DÙNG THỬ]: Đã hoàn thành trọn vẹn 20/20 bài đăng! Vui lòng nâng cấp bản quyền để tiếp tục.',
      });
      break;
    }

    if (shouldStop) break;

    // Giãn cách nghỉ an toàn giữa 2 nhóm (Kèm Jitter ngẫu nhiên tránh nhịp máy tính)
    if (i < groupsToRun.length - 1) {
      // 1. Sau mỗi 4 nhóm, nghỉ xả hơi (Cooling Break) 90 - 120s
      if ((i + 1) % 4 === 0) {
        const coolingSec = 90 + Math.floor(Math.random() * 30);
        for (let c = coolingSec; c > 0; c--) {
          if (shouldStop) break;
          await updateStatus({
            isRunning: true,
            currentIndex: i + 1,
            totalGroups: groupsToRun.length,
            currentGroupName: group.name,
            statusText: `🛡️ [Chống Checkpoint]: Đã đăng ${i + 1} nhóm liên tiếp. Đang nghỉ xả hơi ${c}s...`,
          });
          await interruptibleSleep(1000);
        }
      }

      // 2. Giãn cách ngẫu nhiên an toàn giữa các bài (+0 đến 20s ngẫu nhiên)
      const randomJitter = Math.floor(Math.random() * 20);
      const waitTime = Math.max(25, delaySec) + randomJitter;

      for (let sec = waitTime; sec > 0; sec--) {
        if (shouldStop) break;
        await updateStatus({
          isRunning: true,
          currentIndex: i + 1,
          totalGroups: groupsToRun.length,
          currentGroupName: group.name,
          statusText: `Đã xong ${i + 1}/${groupsToRun.length}. Nghỉ an toàn ${sec}s (kèm jitter ngẫu nhiên)...`,
        });
        await interruptibleSleep(1000);
      }
    }
  }

  isRunning = false;
  activeTabId = null;
  stopKeepAlive();
  const finalMsg = shouldStop ? '⏹️ Đã dừng tiến trình theo yêu cầu của bạn.' : '✓ Đã hoàn thành đăng tất cả các nhóm đã chọn!';
  await updateStatus({
    isRunning: false,
    currentIndex: groupsToRun.length,
    totalGroups: groupsToRun.length,
    statusText: finalMsg,
  });
}

// DÒ TÌM NHÓM FACEBOOK THEO TỪ KHÓA (Không bấm Tham gia hàng loạt trên trang tìm kiếm, đóng tab an toàn bằng await)
async function handleSearchGroups({ keyword, minMembers = 0 }) {
  if (!keyword) throw new Error('Vui lòng nhập từ khóa tìm kiếm nhóm!');

  // Sử dụng đường dẫn tìm kiếm chuẩn của Facebook: https://www.facebook.com/search/groups/?q=...
  const searchUrl = `https://www.facebook.com/search/groups/?q=${encodeURIComponent(keyword)}`;
  const tab = await chrome.tabs.create({ url: searchUrl, active: true });

  try {
    // Chờ nạp trang
    for (let wait = 0; wait < 12; wait++) {
      try {
        const t = await chrome.tabs.get(tab.id);
        if (t.status === 'complete') break;
      } catch (e) {}
      await sleep(1000);
    }
    await sleep(3500);

    let response = null;
    for (let r = 0; r < 5; r++) {
      try {
        response = await chrome.tabs.sendMessage(tab.id, {
          action: 'SCAN_AND_PARSE_GROUPS',
          minMembers: parseInt(minMembers, 10) || 0,
        });
        if (response && response.groups) break;
      } catch (err) {
        console.log(`[AutoRecruit Background] Đợi content script nạp trang tìm kiếm (lần ${r + 1}/5)...`);
        if (r === 2) {
          try {
            await chrome.scripting.executeScript({
              target: { tabId: tab.id },
              files: ['content.js'],
            });
          } catch (injErr) {}
        }
        await sleep(2000);
      }
    }

    await sleep(1000);
    return response || { success: true, groups: [] };
  } finally {
    if (tab?.id) {
      await chrome.tabs.remove(tab.id).catch(() => {});
    }
  }
}

// TỰ ĐỘNG THAM GIA CÁC NHÓM ĐÃ CHỌN VÀ THÊM VÀO DANH SÁCH ĐĂNG BÀI
async function handleBatchJoinAndAddGroups({ groupsToProcess = [] }) {
  if (!groupsToProcess.length) {
    return { success: false, message: 'Danh sách nhóm cần xử lý trống!' };
  }

  console.log(`[AutoRecruit Background] 🚀 Bắt đầu tự động tham gia ${groupsToProcess.length} nhóm...`);
  startKeepAlive();

  let joinedCount = 0;
  let alreadyJoinedCount = 0;
  let failedCount = 0;

  for (let i = 0; i < groupsToProcess.length; i++) {
    const group = groupsToProcess[i];
    let groupUrl = group.link;
    if (!groupUrl.startsWith('http')) {
      groupUrl = `https://www.facebook.com/groups/${groupUrl.replace(/^groups\//, '')}/`;
    }

    await updateStatus({
      isRunning: true,
      currentIndex: i + 1,
      totalGroups: groupsToProcess.length,
      currentGroupName: group.name,
      statusText: `Đang tham gia nhóm ${i + 1}/${groupsToProcess.length}: ${group.name}...`,
    });

    let tab = null;
    try {
      tab = await chrome.tabs.create({ url: groupUrl, active: true });

      // Chờ nạp trang
      for (let wait = 0; wait < 12; wait++) {
        try {
          const t = await chrome.tabs.get(tab.id);
          if (t.status === 'complete') break;
        } catch (e) {}
        await sleep(1000);
      }
      await sleep(2500);

      // Gửi lệnh sang content script thực hiện bấm Tham gia
      let res = null;
      for (let retry = 0; retry < 4; retry++) {
        try {
          res = await chrome.tabs.sendMessage(tab.id, { action: 'AUTO_JOIN_GROUP' });
          if (res) break;
        } catch (msgErr) {
          if (retry === 1) {
            try {
              await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                files: ['content.js'],
              });
            } catch (e) {}
          }
          await sleep(2000);
        }
      }

      if (res && res.success) {
        if (res.message && res.message.includes('Đã là thành viên')) {
          alreadyJoinedCount++;
        } else {
          joinedCount++;
        }
        group.joined = true;
      } else {
        failedCount++;
      }

      await sleep(2000);
      if (tab?.id) chrome.tabs.remove(tab.id).catch(() => {});
    } catch (err) {
      console.warn('[AutoRecruit Background] Lỗi tham gia nhóm:', group.name, err);
      failedCount++;
      if (tab?.id) chrome.tabs.remove(tab.id).catch(() => {});
    }

    // Giãn cách an toàn giữa 2 lần tham gia nhóm (nghỉ 4 giây chống spam)
    if (i < groupsToProcess.length - 1) {
      for (let s = 4; s > 0; s--) {
        await updateStatus({
          isRunning: true,
          currentIndex: i + 1,
          totalGroups: groupsToProcess.length,
          currentGroupName: group.name,
          statusText: `Đã xong ${group.name}. Chờ ${s}s an toàn trước nhóm kế tiếp...`,
        });
        await sleep(1000);
      }
    }
  }

  // Tự động thêm các nhóm này vào danh sách đăng bài (savedGroups)
  const storageData = await chrome.storage.local.get(['savedGroups']);
  const currentSaved = storageData.savedGroups || [];
  let addedCount = 0;

  groupsToProcess.forEach((g) => {
    if (!currentSaved.some((item) => item.link === g.link)) {
      currentSaved.push({
        id: g.id || 'grp_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
        name: g.name,
        link: g.link,
        enabled: true,
      });
      addedCount++;
    }
  });

  await chrome.storage.local.set({ savedGroups: currentSaved });

  stopKeepAlive();
  await updateStatus({
    isRunning: false,
    currentIndex: groupsToProcess.length,
    totalGroups: groupsToProcess.length,
    statusText: `✓ Đã tham gia xong & thêm ${addedCount} nhóm mới vào danh sách đăng bài!`,
  });

  // Ghi nhật ký vào Lịch sử
  await addHistoryEntry({
    groupName: `Tham gia ${groupsToProcess.length} nhóm`,
    groupLink: '#',
    postTitle: 'Tự động Tham gia Nhóm',
    status: 'success',
    type: 'manual',
    message: `Thành công: ${joinedCount + alreadyJoinedCount}, Thất bại: ${failedCount}, Nạp mới: ${addedCount}`,
  });

  return {
    success: true,
    joinedCount,
    alreadyJoinedCount,
    failedCount,
    addedCount,
    updatedGroups: currentSaved,
  };
}
